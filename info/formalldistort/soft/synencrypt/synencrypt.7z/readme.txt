synencrypt - замена слов и фраз синонимами из изменяемых словарей, расположенных в файлах frazbl.js sinonimbl.js slovar_abramova.js и замена кириллических букв похожими латинскими и греческими. Использует html,css,javascript.

автор: llll
ВКонтакте
http://vk.com/kyznec_tor

сайт: http://formalldistort.org
сайт: http://www.L4soft.narod.ru

2014 год

GNU GENERAL PUBLIC LICENSE SOFT
