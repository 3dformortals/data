var frazbl=fr={};
fr["потому_что"]="так_как"
