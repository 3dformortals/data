﻿var nawel;
var povtor;
var i;
var j;
var k;
var jump;
var dbsplit;
var zapros=document.getElementById("iinput").value;
var interes=zapros.split("");
for(i=0;i<=db.length-1;i++){
 var gdepoisk=db[i].split("");
 for(j=0;j<=(gdepoisk.length)-(interes.length-1);j++){
  for(k=0;k<=interes.length-1;k++){
  if(simvol(interes[k],gdepoisk[j+k])){
   nawel++;
   if(nawel==interes.length && db[i]!=povtor){

   

 dbsplit=db[i].split("+++")
 if(dbsplit[0]!="" && dbsplit[1]!=""){document.write("<tr id='zapisi'><td id='forimg'><a href='" + dbsplit[0] + "'><img alt='" + dbsplit[0] + "' title='" + dbsplit[0] + "'  src='stroka.png'></a></td><td id='forstroka'><span id='stroka'>" + dbsplit[1] + "</span></td></tr>")};
 if(dbsplit[0]=="" && dbsplit[1]!="" && dbsplit[1]!=undefined){document.write("<tr id='zapisi'><td id='forimg'><img alt='запись' title='запись'  src='koment.png'></td><td id='forkoment'><span id='koment'>" + dbsplit[1] + "</span></td></tr>")};
    povtor=db[i];}
}
  else{
  nawel=0;}
  }
  }
 }
 
function simvol(x,y){
var regExp = new RegExp("[" + x + "]","i");
return regExp.test(y);
}

// if(dbsplit[0]!="" && dbsplit[1]==""){document.write("<tr id='zapisi'><td id='forimg'><img alt='раздел' title='раздел'  src='razdel.png'  tabindex='" + jump + "'></td><td id='forrazdel'><span id='razdel'><h3>" + dbsplit[0] + "</h3></span></td></tr>")};

// if(dbsplit[0]=="" && dbsplit[1]==""){document.write("<tr id='zapisi'><td id='forimg'><img src='razdel.png'></td><td></td></tr>")};
// if(dbsplit[0]=="" && dbsplit[1]==undefined){document.write("<tr id='zapisi'><td id='forimg'><img src='koment.png'></td><td></td></tr>")}

//if(simvol(interes[k],gdepoisk[j+k]))...без учета регистра
//if(gdepoisk[j+k]==interes[k])... с учетом регистра самоделка
// УБРАТЬ ПОВТОР,ВОЗМОЖНО СЕТЬ НАЛАДИТЬ
