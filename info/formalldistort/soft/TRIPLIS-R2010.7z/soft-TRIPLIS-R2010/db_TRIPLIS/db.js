﻿var db = new Array(


"AROMA+++"
,"http://www.chanel.com/fb/um.php?la=ru&lo=ru&re=chanelcom&wsmlentry=ch4500+++CHANEL-COCO MADEMOISELLE"
,"http://www.yves-rocher.fr/control/naturelle/+++Yves Rocher - NATURELLE"
,"http://shop.elizabetharden.com/product/index.jsp?productId=2523245&cp=2571503.2552726+++Elizabeth Arden - RED DOOR"
,"http://uk.burberry.com/fcp/product/clothing-accessories//BURBERRY-FOR-WOMEN-50ML/10000000226?lastcategoryurl=true+++BURBERRY FOR WOMEN"
,"+++Ella Mikao - Yujin Gold"
,"COSA NOSTRA - PARIS ELYSEES PARFUMS+++"
,"http://www.parfumxxi.ru/?p=394+++Пари Элизе - PARIS ELYSEES PARFUMS,Мужская парфюмерия Cosa Nostra,King,Dollar,Number Number,женские туалетные воды:Dancing, Marilyn | Парфюмерия XXI век"
,"http://www.paris-elysees.com/+++paris elysees"
,"AROMA BAD+++"
,"+++Chanel - CHANCE"
,"+++Oriflame - Enigma"


);


//ССЫЛКА+++КОМЕНТАРИЙ
//заголовок+++
//+++коментарий