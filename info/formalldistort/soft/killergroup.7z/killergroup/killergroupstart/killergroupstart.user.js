﻿// ==UserScript==
// @name           killergroupstart
// @namespace      http://vkontakte.ru/vblxod
// @description    выбирает группы для выхода от Х до У , Й штук... и выводит строки на экран в отдельно открывающемся окошке, из него и надо делать копипаст или копирововставляние в файл второго скрипта killergroupfinish
// @include        http://vkontakte.ru/groups.php
// ==/UserScript==
		var xforfuncleave;
		var yforfuncleave;
		var adres1;
		var adres2;
		var hrefkill;
		var killer;
		var printos;
			
		function confgroup(){
		
		if(confirm("удалить неразрывный диапазон групп(выйти из них)?(задается номер начальной группы для удаления и номер конечной группы)")){
		
		win2 = window.open("","kod");
				
		var onekiller = parseInt(prompt('номер начальной удаляемой группы',"2"));
		var tokiller = parseInt(prompt('номер конечной удаляемой группы',"2"));
		for(var j=onekiller;j<tokiller+1;j++){
		
		
		adres1 = "/html/body/div/div/div[3]/div[2]/div/div/div[3]/div/div["
		adres2 = "]/table/tbody/tr/td[3]/ul/li[2]/a"
		killer = document.evaluate(adres1 + j + adres2, document, null, XPathResult.UNORDERED_NODE_SNAPSHOT_TYPE, null);
		
		hrefkill = killer.snapshotItem(0).href;
		xforfuncleave = hrefkill.toString();
		printos = xforfuncleave.split(":");
		
		win2.document.body.innerHTML += 'unsafeWindow.' + printos[1] + ';<br>';	

		xforfuncleave = xforfuncleave.split("javascript:processLeave(");
		xforfuncleave = xforfuncleave[1].split(",");
		xforfuncleave = parseFloat(xforfuncleave[0]);
		yforfuncleave = hrefkill.toString();
		yforfuncleave = yforfuncleave.split("javascript:processLeave(");
		yforfuncleave = yforfuncleave[1].split(",");
		yforfuncleave = yforfuncleave[1].split("'");
		
		//unsafeWindow.processLeave(xforfuncleave, yforfuncleave);
		
		
		
		
				
				}
		}
		
		}
		
			
	confgroup();


