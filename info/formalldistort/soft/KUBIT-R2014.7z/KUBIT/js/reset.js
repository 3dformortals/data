function resetresult(id){
	document.getElementById(id).innerHTML=''
}
